document.addEventListener("DOMContentLoaded", () => {
  const categoryCheckboxes = document.querySelectorAll(".filter-category");
  const subCheckboxes = document.querySelectorAll(".filter-sub");
  const productCards = document.querySelectorAll(".product-card");

  function filterProducts() {
    const selectedCategories = Array.from(categoryCheckboxes)
      .filter(checkbox => checkbox.checked)
      .map(checkbox => checkbox.value);

    const selectedSubs = Array.from(subCheckboxes)
      .filter(checkbox => checkbox.checked)
      .map(checkbox => checkbox.value);

    productCards.forEach(card => {
      const category = card.dataset.category;
      const sub = card.dataset.sub;

      const categoryMatch = selectedCategories.length === 0 || selectedCategories.includes(category);
      const subMatch = !sub || selectedSubs.length === 0 || selectedSubs.includes(sub);

      if (categoryMatch && subMatch) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
  }

  categoryCheckboxes.forEach(cb => cb.addEventListener("change", filterProducts));
  subCheckboxes.forEach(cb => cb.addEventListener("change", filterProducts));

  // Initial filter (show all)
  filterProducts();
});
